window.onload = function () {
    const storedRecipe = JSON.parse(localStorage.getItem('ricettaCorrente'));
    
    if (!storedRecipe) {
        alert('Nessuna ricetta selezionata!');
        return;
    }

    document.getElementById('recipeTitle').textContent = storedRecipe.title;
    document.getElementById('recipeImage').src = storedRecipe.image;
    
    const url = `https://api.spoonacular.com/recipes/${storedRecipe.id}/information?apiKey=${APIKEY}`;

    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error(`Errore nella richiesta: ${response.statusText}`);
            }
            return response.json();
        })
        .then(data => {

            document.getElementById('recipeTime').textContent = `${data.readyInMinutes} minuti`;

            const ingredientsList = document.getElementById('recipeIngredients');
            ingredientsList.innerHTML = ''; 
            if (data.extendedIngredients && data.extendedIngredients.length > 0) {
                data.extendedIngredients.forEach(ingredient => {
                    const li = document.createElement('li');
                    li.textContent = `${ingredient.amount} ${ingredient.unit} ${ingredient.name}`;
                    ingredientsList.appendChild(li);
                });
            } else {
                ingredientsList.innerHTML = '<li>Ingredienti non disponibili.</li>';
            }

            const stepsList = document.getElementById('recipeSteps');
            stepsList.innerHTML = ''; 
            if (data.analyzedInstructions && data.analyzedInstructions.length > 0) {
                data.analyzedInstructions[0].steps.forEach(step => {
                    const li = document.createElement('li');
                    li.textContent = step.step;
                    stepsList.appendChild(li);
                });
            } else {
                stepsList.innerHTML = '<li>Non sono disponibili istruzioni per questa ricetta.</li>';
            }
        })
        .catch(error => {
            console.error('Errore nel caricamento dei dettagli della ricetta:', error.message);
        });
};
