let saveId="";

window.onload=function(){
    const searchBar = document.getElementById('search-bar');
    const suggestions = document.getElementById('suggestions');

    searchBar.addEventListener('keyup', () => {
        const query = searchBar.value.trim().toUpperCase(); 
        if (query.length > 3) {
          fetchRecipes(query); 
        } else {
          suggestions.innerHTML = ''; 
        }
      });
}
function LikeCuore(event) {
    const cuore = event.target; // Ottieni l'elemento cliccato
    cuore.classList.toggle('cliccato');
    
    const id = saveId; // Ottieni l'ID dal data-id

    console.log(id); // Stampa l'ID della ricetta

    const titolo = document.getElementsByClassName('title')[0].textContent; // Prendi il titolo
    const immagine = document.querySelector('#recipe-details img').src; // Prendi l'immagine

    const ricetta = {
        title: titolo,
        image: immagine,    
        id: id
    };

    // Recupera i preferiti dal localStorage
    let preferiti = JSON.parse(localStorage.getItem('preferiti')) || [];

    if (cuore.classList.contains('cliccato')) {
        // Aggiungi ai preferiti
        preferiti.push(ricetta);
    } else {
        // Rimuovi dai preferiti
        preferiti = preferiti.filter(pref => pref.id !== ricetta.id);
    }

    // Salva i preferiti aggiornati nel localStorage
    localStorage.setItem('preferiti', JSON.stringify(preferiti));
}

function fetchRecipes(query) {
  const url = 'https://api.spoonacular.com/recipes/complexSearch';
  const params = new URLSearchParams({
    query: query,              
    number: 5,                
    apiKey: APIKEY,   
  });

  fetch(`${url}?${params.toString()}`)
    .then(response => {
      if (!response.ok) {
        throw new Error(`Errore: ${response.status}`);
      }
      return response.json();
    })
    .then(data => {
      displaySuggestions(data.results); 
    })
    .catch(error => {
      console.error('Errore nella richiesta:', error.message);
    });
}

function displaySuggestions(recipes) {
    const suggestions = document.getElementById('suggestions');
    const searchBar = document.getElementById('search-bar');
    suggestions.innerHTML = ''; 
    recipes.forEach(recipe => {
      const suggestion = document.createElement('div');
      suggestion.textContent = recipe.title;  
      suggestion.classList.add('suggestion-item'); 
      suggestion.addEventListener('click', () => {
        showRecipeDetails(recipe); 
        searchBar.value = ''; 
        suggestions.innerHTML = ''; 
      });
      suggestions.appendChild(suggestion);
    });
}

function showRecipeDetails(recipe) {
    const recipeDetails = document.getElementById('recipe-details');
  recipeDetails.innerHTML = `
    <h2 class="title">${recipe.title}</h2>
    <img src="${recipe.image}" alt="${recipe.title} id="recepie-image" style="max-width: 300px;">
    <div class="div-prefe"> 
    <p> Aggiungi ai preferiti:</p>
    <i class="fas fa-heart cuore"></i>
    </div>
  `;
    saveId=recipe.id;

  fetchIngredientDetails(recipe.id);
  fetchPreparationDetails(recipe.id);
  const cuori = document.querySelectorAll('.cuore');
    cuori.forEach(cuore => {
         cuore.addEventListener('click', LikeCuore);
     });
}

function fetchPreparationDetails(recipeId) {
    const url = `https://api.spoonacular.com/recipes/${recipeId}/analyzedInstructions`;
    const params = new URLSearchParams({
      apiKey: APIKEY,  
    });
  
    fetch(`${url}?${params.toString()}`)
      .then(response => {
        if (!response.ok) {
          throw new Error(`Errore: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        displayPreparationDetails(data); 
      })
      .catch(error => {
        console.error('Errore nella richiesta preparazione:', error.message);
      });
  }
function fetchIngredientDetails(recipeId) {
    const url = `https://api.spoonacular.com/recipes/${recipeId}/ingredientWidget.json`;
    const params = new URLSearchParams({
      apiKey: APIKEY,  
    });
  
    fetch(`${url}?${params.toString()}`)
      .then(response => {
        if (!response.ok) {
          throw new Error(`Errore: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        displayIngredientDetails(data.ingredients); 
      })
      .catch(error => {
        console.error('Errore nella richiesta ingredienti:', error.message);
      });
  }

  function displayIngredientDetails(ingredients) {
    const ingredientDetails = document.getElementById('ingredient-details'); 
    ingredientDetails.innerHTML = ''; 
    const ingredientsList = document.createElement('ul');
    
    ingredients.forEach(ingredient => {
      const listItem = document.createElement('li');
      listItem.textContent = `${ingredient.name}: ${ingredient.amount.metric.value} ${ingredient.amount.metric.unit}`;
      ingredientsList.appendChild(listItem);
    });
  
    ingredientDetails.appendChild(ingredientsList); 
  }

  function displayPreparationDetails(instructions) {
    const preparationDetails = document.getElementById('preparation-details');
    preparationDetails.innerHTML = ''; 
    if (instructions.length > 0) {
      const steps = instructions[0].steps; 
      const stepsList = document.createElement('ol'); 
  
      steps.forEach(step => {
        const listItem = document.createElement('li');
        listItem.textContent = step.step; 
        stepsList.appendChild(listItem);
      });
  
      preparationDetails.appendChild(stepsList); 
    } else {
      preparationDetails.innerHTML = '<p>Non sono disponibili istruzioni per questa ricetta.</p>';
    }
  } 
