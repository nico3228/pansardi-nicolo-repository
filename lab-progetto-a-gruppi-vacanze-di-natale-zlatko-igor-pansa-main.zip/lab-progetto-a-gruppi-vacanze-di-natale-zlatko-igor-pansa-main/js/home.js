let ricetteCaricate = []; 
let ricettaCorrente = 0; 

window.onload = function() {
    const buttonNext = document.getElementById("btn-next");
    const buttonPrev = document.getElementById("btn-prev");
    const buttonVediRicetta=document.getElementById("vedi-ricettaBtn");

    caricaImmagini(); 
    buttonNext.addEventListener("click", caricaNuovaRicetta); 
    buttonPrev.addEventListener("click", caricaRicettaPrecedente); 
    buttonVediRicetta.addEventListener("click",VediRicettaCorrente);

  
};
function VediRicettaCorrente() {
    const currentRecipe = ricetteCaricate[ricettaCorrente];

    localStorage.setItem('ricettaCorrente', JSON.stringify({
        title: currentRecipe.title,
        image: currentRecipe.image,
        id: currentRecipe.id 
    }));

    window.location.href = 'dettagliricetta.html';
}


function caricaImmagini() {
    const isVegan = localStorage.getItem('isVegan') === 'true';
    const isGlutenFree = localStorage.getItem('isGlutenFree') === 'true';
    const noConditions = localStorage.getItem('noConditions') === 'true';

    const randomOffset = Math.floor(Math.random() * 500);

    let queryParams = {
        number: 5, 
        offset: randomOffset, 
        apiKey: APIKEY
    };

    let introMessage = '';

    if (isVegan) {
        queryParams.diet = 'vegan';
        introMessage = 'Queste sono ricette vegane consigliate per te!';
    } else if (isGlutenFree) {
        queryParams.intolerances = 'gluten';
        introMessage = 'Queste sono ricette senza glutine consigliate per te!';
    } else if (noConditions) {
        introMessage = 'Ecco alcune ricette che potrebbero piacerti!';
    }

    document.getElementById('introMessage').textContent = introMessage;

    const url = 'https://api.spoonacular.com/recipes/complexSearch';
    const params = new URLSearchParams(queryParams);

    fetch(`${url}?${params.toString()}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`Errore: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            displaySuggestions(data.results);
        })
        .catch(error => {
            console.error('Errore nella richiesta:', error.message);
        });
}

function displaySuggestions(results) {
    ricetteCaricate = results; 
    ricettaCorrente = 0; 

    aggiornaCarousel(ricetteCaricate[ricettaCorrente]);
}

function caricaNuovaRicetta() {
    ricettaCorrente = (ricettaCorrente + 1) % ricetteCaricate.length; // Avanza nell'array delle ricette

    aggiornaCarousel(ricetteCaricate[ricettaCorrente]); // Aggiorna il carosello con la nuova ricetta
}

function caricaRicettaPrecedente() {
    ricettaCorrente = (ricettaCorrente - 1 + ricetteCaricate.length) % ricetteCaricate.length; // Torna indietro nell'array delle ricette

    aggiornaCarousel(ricetteCaricate[ricettaCorrente]); // Aggiorna il carosello con la ricetta precedente
}

function aggiornaCarousel(recipe) {
    const carouselContent = document.getElementById('carouselContent');
    carouselContent.innerHTML = `
        <div class="carousel-item active">
            <img src="${recipe.image}" class="img img-fluid w-100" alt="${recipe.title}">
            <div class="carousel-caption d-none d-md-block">
                <h5>${recipe.title}</h5>
            </div>
        </div>`;
}