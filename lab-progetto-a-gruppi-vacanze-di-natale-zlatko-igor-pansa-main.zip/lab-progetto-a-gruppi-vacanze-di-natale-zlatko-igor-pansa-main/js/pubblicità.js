const banners = [
    {
        description: "Visita Fatto in casa per ricette buonissime",
        image: "img/fattoInCasaLogo-banner.jpg",
        link: "https://www.fattoincasadabenedetta.it"
    },
    {
        description: "Guarda masterchef su Sky",
        image: "img/masterchef-banner.png",
        link: "https://masterchef.sky.it/puntate"
    },
    {
        description: "Trova ricette facili e veloci su Giallo Zafferano",
        image: "img/gialloZafferano-banner-pubblicità.png",
        link: "https://www.giallozafferano.it"
    }
];

document.addEventListener('DOMContentLoaded', function() {// uso questo perchè senno i due java vanno in conflitto
    populateBanners();
});
function getRandomBanner() {
    const randomIndex = Math.floor(Math.random() * banners.length);
    return banners[randomIndex];
}

function populateBanners() {
    const leftBanner = document.querySelector('.ad-banner-left');
    const rightBanner = document.querySelector('.ad-banner-right');

    const selectedBanner = getRandomBanner();

    leftBanner.querySelector('.banner-description').textContent = selectedBanner.description;
    leftBanner.querySelector('img').src = selectedBanner.image;
    leftBanner.querySelector('.banner-link').href = selectedBanner.link;
    leftBanner.querySelector('.banner-link').textContent = "Scopri di più";

    rightBanner.querySelector('.banner-description').textContent = selectedBanner.description;
    rightBanner.querySelector('img').src = selectedBanner.image;
    rightBanner.querySelector('.banner-link').href = selectedBanner.link;
    rightBanner.querySelector('.banner-link').textContent = "Scopri di più";
}