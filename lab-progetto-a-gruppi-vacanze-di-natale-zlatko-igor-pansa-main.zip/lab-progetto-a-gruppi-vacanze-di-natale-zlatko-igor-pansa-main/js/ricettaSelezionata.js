
window.onload = function () {
    const cuori = document.querySelectorAll('.cuore');

    cuori.forEach(cuore => {
        cuore.addEventListener('click', LikeCuore);
    });
    fetchRicette();
};

function LikeCuore(event) {
    const cuore = event.target; 
    cuore.classList.toggle('cliccato'); // Alterna la classe 'cliccato'

    // Trova il contenitore della ricetta
    const ricettaElement = cuore.closest('.ricetta-item');
    const titolo = ricettaElement.querySelector('h3').textContent;
    const immagine = ricettaElement.querySelector('img').src;
    const id = ricettaElement.getAttribute('data-id'); 
    const ricetta = {
        title: titolo,
        image: immagine,
        id: id 
    };

    let preferiti = JSON.parse(localStorage.getItem('preferiti')) || [];

    if (cuore.classList.contains('cliccato')) {
        preferiti.push(ricetta);
    } else {
        preferiti = preferiti.filter(pref => pref.title !== ricetta.title);
    }

    localStorage.setItem('preferiti', JSON.stringify(preferiti));
}

const categoryMap = {
    tutte: '',
    antipasti: 'appetizer',
    primi: 'main course',
    secondi: 'side dish',
    dolci: 'dessert'
};

function getCategoriaFromURL() {
    const params = new URLSearchParams(window.location.search);
    return params.get('categoria') || 'tutte'; // Default: 'tutte'
}

function getRandomOffset() {
    return Math.floor(Math.random() * 1000); 
}

function fetchRicette() {
    const categoria = getCategoriaFromURL();
    const spoonacularApiKey = APIKEY; 
    const type = categoryMap[categoria] || '';
    const offset = getRandomOffset(); // Offset casuale per ricette diverse
    const url = `https://api.spoonacular.com/recipes/complexSearch?apiKey=${spoonacularApiKey}&type=${type}&number=10&offset=${offset}&addRecipeInformation=true`;

    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error(`Errore nella richiesta: ${response.statusText}`);
            }
            return response.json();
        })
        .then(data => {
            displayRicette(data.results);
        })
        .catch(error => console.error('Errore nel caricamento delle ricette:', error));
}

function displayRicette(ricette) {
    const container = document.getElementById('ricette-container');
    container.innerHTML = '';

    ricette.forEach(ricetta => {
        const ricettaElement = document.createElement('div');
        ricettaElement.classList.add('ricetta-item');
        ricettaElement.setAttribute('data-id', ricetta.id);

        ricettaElement.innerHTML = `
            <h3>${ricetta.title}</h3>
            <img src="${ricetta.image}" alt="${ricetta.title}">
            <p>${ricetta.summary}</p>
        `;

        const cuoreIcon = document.createElement('i');
        cuoreIcon.classList.add('fas', 'fa-heart', 'cuore');
        cuoreIcon.addEventListener('click', LikeCuore);

        const btnMostraDettagli = document.createElement('button');
        btnMostraDettagli.classList.add('dettagli-btn', 'btn', 'btn-primary');
        btnMostraDettagli.textContent = "Mostra Dettagli";
        btnMostraDettagli.addEventListener('click', () => {
            localStorage.setItem('ricettaCorrente', JSON.stringify(ricetta));
            window.location.href = 'dettagliricetta.html';
        });

        const actionsContainer = document.createElement('div');
        actionsContainer.classList.add('actions-container');
        actionsContainer.appendChild(cuoreIcon);
        actionsContainer.appendChild(btnMostraDettagli);

        ricettaElement.appendChild(actionsContainer);

        container.appendChild(ricettaElement);
    });
}
