"use strict"

window.onload = function () {
    localStorage.removeItem('allergies');
    gestisciPuntini();
    const togglePasswordButton = document.getElementById('toggle-password');
    if (togglePasswordButton) {
        togglePasswordButton.addEventListener('click', togglePasswordVisibility);
    }

    const finishButton = document.getElementById("finish-button");
    finishButton.addEventListener("click", function () {
        salvaNelLocalStorage(); // Salva i dati nel localStorage quando si clicca "Finish"
        window.location.href = "home.html";
    });
};

// Variabili temporanee
let tempEmail, tempPassword, tempAllergies, tempIsVegan, tempIsGlutenFree, tempNoConditions; // perchè voglio salvare nel local storage solo quando clicco fine

function gestioneCheckbox() {
    const checkBoxVegetarian = document.getElementById("chkVegetarian");
    const checkBoxGlutenFree = document.getElementById("chkGlutenFree");
    const checkBoxNoConditions = document.getElementById("chkNoConditions");

    if (!checkBoxVegetarian || !checkBoxGlutenFree || !checkBoxNoConditions) {
        console.error("Una o più checkbox non sono state trovate.");
        return false;
    }

    // Controlla se almeno una checkbox è selezionata
    if (checkBoxGlutenFree.checked || checkBoxNoConditions.checked || checkBoxVegetarian.checked) {
        return true;
    } else {
        alert("Seleziona almeno una checkbox.");
        return false;
    }
}

function togglePasswordVisibility() {
    const passwordInput = document.getElementById('confirm-password-input');
    const togglePasswordButton = document.getElementById('toggle-password');
    
    if (!passwordInput || !togglePasswordButton) return;

    const savedPassword = tempPassword;

    const currentType = passwordInput.getAttribute('type');
    
    if (currentType === 'password') {
        passwordInput.setAttribute('type', 'text');
        passwordInput.value = savedPassword; 
        togglePasswordButton.textContent = 'Hide';
    } else {
        passwordInput.setAttribute('type', 'password');
        passwordInput.value = '********'; 
        togglePasswordButton.textContent = 'Show';
    }
}


function validateEmail() {
    const email = document.getElementById("exampleInputEmail1").value;
    const emailError = document.getElementById("email-error");
    const regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;

    if (!regex.test(email)) {
        emailError.style.display = "block";
        return false;
    } else {
        emailError.style.display = "none";
        tempEmail = email; // Salva temporaneamente nel campo email
        console.log("Email temporanea salvata:", email);
        return true;
    }
}

function validatePassword() {
    const password = document.getElementById("password").value;
    const checkPassword = document.getElementById("checkPassword").value;

    // Se la password e la conferma password non corrispondono
    if (password !== checkPassword) {
        alert("Le password non corrispondono.");
        return false;
    }
    tempPassword = password; // Salva temporaneamente la password
    console.log("Password temporanea salvata:", password);
    return true;
}

function checkRequiredFields() {
    const email = document.getElementById("exampleInputEmail1").value;
    const password = document.getElementById("password").value;
    const checkPassword = document.getElementById("checkPassword").value;

    // Se l'email o le password non sono compilate, ritorna falso
    if (email === "" || password === "" || checkPassword === "") {
        alert("Per favore, compila tutti i campi richiesti.");
        return false;
    }

    return true;
}

function salvaDatiSpeciali() {
    const allergies = document.getElementById("allergies").value;
    const isVegan = document.getElementById("chkVegetarian").checked;
    const isGlutenFree = document.getElementById("chkGlutenFree").checked;
    const isConditions = document.getElementById("chkNoConditions").checked;

    tempAllergies = allergies;
    tempIsVegan = isVegan;
    tempIsGlutenFree = isGlutenFree;
    tempNoConditions = isConditions;

    console.log("Allergies temporanee:", allergies);
    console.log("Is Vegan temporaneo:", isVegan);
    console.log("Is Gluten-Free temporaneo:", isGlutenFree);
}

function gestisciPuntini() {
    $(document).ready(function () {
        let currentStep = 1;

        const buttonNext = $('#btn-next');
        const buttonPrev = $('#btn-prev');
        const finishButton = $('#finish-button');
        const dots = $('.dot');

        function updateButtons() {
            if (currentStep === 1) {
                buttonPrev.hide();
            } else {
                buttonPrev.show();
            }

            if (currentStep === 3) {
                buttonNext.hide(); 
                finishButton.show();
                aggiungiInformazioni();
            } else {
                buttonNext.show();
                finishButton.hide();
            }
        }

        buttonNext.on('click', function () {
            if (currentStep === 1) {
                if (checkRequiredFields() && validateEmail() && validatePassword()) {
                    moveToNextStep();
                }
            } else if (currentStep === 2) {
                if (gestioneCheckbox()) {
                    salvaDatiSpeciali();
                    moveToNextStep();
                }
            }
        });

        buttonPrev.on('click', function () {
            if (currentStep > 1) { 
                $(`#form-step-${currentStep}`).fadeOut(300, function () {
                    currentStep--;
                    $(`#form-step-${currentStep}`).fadeIn(300);
                    dots.removeClass('active');
                    $(`.dot:nth-child(${currentStep})`).addClass('active');
                    updateButtons();
                });
            }
        });

        function moveToNextStep() {
            if (currentStep < 3) {
                $(`#form-step-${currentStep}`).fadeOut(300, function () {
                    currentStep++;
                    $(`#form-step-${currentStep}`).fadeIn(300);
                    dots.removeClass('active');
                    $(`.dot:nth-child(${currentStep})`).addClass('active');
                    updateButtons();
                });
            }
        }

        updateButtons();
    });
}

function salvaNelLocalStorage() {
    if (tempEmail) {
        localStorage.setItem('email', tempEmail);
        console.log("Email salvata nel localStorage");
    }

    if (tempPassword) {
        localStorage.setItem('password', tempPassword);
        console.log("Password salvata nel localStorage");
    }

    if (tempAllergies) {
        localStorage.setItem('allergies', tempAllergies);
        console.log("Allergies salvate nel localStorage");
    }

    if (tempIsVegan !== undefined) {
        localStorage.setItem('isVegan', tempIsVegan);
        console.log("Is Vegan salvato nel localStorage");
    }

    if (tempIsGlutenFree !== undefined) {
        localStorage.setItem('isGlutenFree', tempIsGlutenFree);
        console.log("Is Gluten-Free salvato nel localStorage");
    }

    if (tempNoConditions !== undefined) {
        localStorage.setItem('noConditions', tempNoConditions);
        console.log("No Conditions salvato nel localStorage");
    }
}

function aggiungiInformazioni() {

    const finishEMail = document.getElementById("confirm-email");
    if (finishEMail) {
        finishEMail.innerText = tempEmail ? tempEmail : "No Email";
    }

    const finishPassword = document.getElementById("confirm-password");
    if (finishPassword) {
        finishPassword.innerText = tempPassword ? tempPassword : "No Password";
    }

    const finishAllergies = document.getElementById("confirm-allergies");
    if (finishAllergies) {
        if (tempAllergies === "" || tempAllergies === null) {
            finishAllergies.innerText = "No Allergies";
        } else {
            finishAllergies.innerText = tempAllergies;
        }
    }

    const finishGlutenFree = document.getElementById("confirm-gluten");
    if (finishGlutenFree) {
        if (tempIsGlutenFree) {
            finishGlutenFree.innerText = "Yes";
        } else {
            finishGlutenFree.innerText = "No";
        }
    }

    const finishVegan = document.getElementById("confirm-vegan");
    if (finishVegan) {
        if (tempIsVegan) {
            finishVegan.innerText = "Yes";
        } else {
            finishVegan.innerText = "No";
        }
    }
}
