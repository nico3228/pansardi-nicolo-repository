window.onload = function () {
    const btnCloseProfile = document.getElementById("closeProfile");
    const btnLogOut = document.getElementById("logout");
    const saveDataButton = document.getElementById("saveData");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");
    const confirmPasswordInput = document.getElementById("confirmation-password");
    const allergiesInput = document.getElementById("allergie");
    const veganCheckbox = document.getElementById("vegano");
    const glutenFreeCheckbox = document.getElementById("glutenFree");

    let isEditing = false;

    btnCloseProfile.addEventListener('click', () => {
        window.location.href = "home.html";
    });

    btnLogOut.addEventListener('click',() =>{
        const confirmation = window.confirm("Sei sicuro di voler fare il log out?");

        if (confirmation) {
            localStorage.clear();
            window.location.href = "index.html"; 
        } else {
            return;
        }
    });

    caricaInformazioniNelProfilo();

    function caricaInformazioniNelProfilo() {
        const email = localStorage.getItem('email');
        const password = localStorage.getItem('password');
        const allergies = localStorage.getItem('allergies');
        const isVegan = localStorage.getItem('isVegan') === 'true';
        const isGlutenFree = localStorage.getItem('isGlutenFree') === 'true';

        emailInput.value = email ? email : "";
        passwordInput.value = password ? password : "";
        allergiesInput.value = allergies ? allergies : "Nessuna allergia";
        veganCheckbox.checked = isVegan;
        glutenFreeCheckbox.checked = isGlutenFree;

        emailInput.disabled = true;  // L'email è sempre disabilitata e non modificabile
        passwordInput.disabled = true; 
        confirmPasswordInput.disabled = true; 
        allergiesInput.disabled = true; 
        veganCheckbox.disabled = true;
        glutenFreeCheckbox.disabled = true;
        
        document.querySelector('.field.d-none').classList.add('d-none');

        const lblPassword = document.getElementById("lblPassword");
        lblPassword.textContent = "Password";
    }

    saveDataButton.addEventListener('click', () => {
        if (isEditing) {

            if (passwordInput.value !== confirmPasswordInput.value) {
                alert("Le password non corrispondono!");
                return;
            }

            localStorage.setItem('email', emailInput.value); 
            localStorage.setItem('password', passwordInput.value);
            localStorage.setItem('allergies', allergiesInput.value);
            localStorage.setItem('isVegan', veganCheckbox.checked);
            localStorage.setItem('isGlutenFree', glutenFreeCheckbox.checked);

            disabilitaCampi();

            saveDataButton.textContent = "Aggiorna i tuoi dati";

            isEditing = false;
        } else {
            document.querySelector('.field.d-none').classList.remove('d-none');
            const lblPassword = document.getElementById("lblPassword");

            saveDataButton.textContent = "Salva i dati";

            passwordInput.value = "";
            confirmPasswordInput.value = "";

            lblPassword.textContent = "Insert new Password"; 

            passwordInput.disabled = false;
            confirmPasswordInput.disabled = false;
            allergiesInput.disabled = false;
            veganCheckbox.disabled = false;
            glutenFreeCheckbox.disabled = false;

            isEditing = true;
        }
    });

    function disabilitaCampi() {
        passwordInput.disabled = true;
        confirmPasswordInput.disabled = true;
        allergiesInput.disabled = true;
        veganCheckbox.disabled = true;
        glutenFreeCheckbox.disabled = true;

        const divConfirmationPassword = document.getElementById("divConfirmation");
        divConfirmationPassword.classList.add("d-none");

        const lblPassword = document.getElementById("lblPassword");
        lblPassword.textContent = "Password";
    }
}
