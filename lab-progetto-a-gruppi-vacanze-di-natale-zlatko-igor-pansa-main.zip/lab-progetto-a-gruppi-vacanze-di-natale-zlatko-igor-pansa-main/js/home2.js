document.addEventListener('DOMContentLoaded', function () {
    suggerimentiHome();
    const cuori = document.querySelectorAll('.cuore');

    cuori.forEach(cuore => {
        cuore.addEventListener('click', LikeCuore);
    });
});

function LikeCuore(event) {
    const cuore = event.target; // Ottieni l'elemento cliccato
    cuore.classList.toggle('cliccato'); // Alterna la classe 'cliccato'

    const ricettaElement = cuore.closest('.riquadro-contenuto');
    const titolo = ricettaElement.querySelector('.testo').textContent;
    const immagine = ricettaElement.querySelector('img').src;
    const id = ricettaElement.getAttribute('data-id'); 

    console.log(id);

    const ricetta = {
        title: titolo,
        image: immagine,
        id: id 
    };

    let preferiti = JSON.parse(localStorage.getItem('preferiti')) || [];

    if (cuore.classList.contains('cliccato')) {
        preferiti.push(ricetta);
    } else {
        preferiti = preferiti.filter(pref => pref.title !== ricetta.title);
    }
    localStorage.setItem('preferiti', JSON.stringify(preferiti));
}

function suggerimentiHome() {
    const cachedData = {};

    function getRandomOffset() {
        return Math.floor(Math.random() * 200); // Cambia il range in base ai risultati disponibili
    }

    function fetchCategoryData(category) {
        const offset = getRandomOffset();
        const url = `https://api.spoonacular.com/recipes/complexSearch?query=${category}&number=4&offset=${offset}&apiKey=${APIKEY}`;

        return fetch(url)
            .then(response => {
                if (!response.ok) {
                     console.error(`Errore nella risposta della API: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (!data.results || data.results.length === 0) {
                     console.error('Nessun risultato trovato');
                }

                cachedData[category] = data.results.map(result => ({
                    image: result.image,
                    title: result.title,
                    id: result.id 
                }));
                return cachedData[category];
            })
            .catch(error => {
                console.error(`Errore nel recupero dei dati per ${category}:`, error.message);
            });
    }

    function insertImagesAndDescriptions() {
        const categories = ['fish','meat', 'vegetables', 'desserts'];
    
        categories.forEach(category => {
            const imageContainers = document.querySelectorAll(`.${category} .immagine`);
            const textContainers = document.querySelectorAll(`.${category} .testo`);
            const riquadroContainers = document.querySelectorAll(`.${category} .riquadro-contenuto`);
    
            if (imageContainers.length === 0) {
                console.warn(`Nessun elemento con la classe .${category} trovato nella pagina`);
                return;
            }
    
            fetchCategoryData(category)
                .then(data => {
                    for (let i = 0; i < imageContainers.length; i++) {
                        if (data[i]) {
                            const imgElement = document.createElement('img');
                            
                            const imageUrl = data[i].image || '';
                            
                            imgElement.src = imageUrl;
                            
                            imgElement.onerror = function() {
                                imgElement.src = 'img/Immagine no disponibile (1).jpg'; 
                            };

                            imgElement.style.margin = '0 auto';
                            imgElement.style.maxWidth = '100%';
                            imgElement.style.maxHeight = '200px';
                            imgElement.style.objectFit = 'contain';
    
                            imageContainers[i].innerHTML = ''; 
                            imageContainers[i].appendChild(imgElement);

                            textContainers[i].textContent = data[i].title;
    
                            const riquadroElement = riquadroContainers[i];
                            riquadroElement.setAttribute('data-id', data[i].id); 
                        }
                    }
                })
                .catch(error => {
                    console.error(`Errore nell'inserimento dei dati per ${category}:`, error.message);
                });
        });
    }
    insertImagesAndDescriptions();
}
