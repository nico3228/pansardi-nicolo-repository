"use strict"

window.onload=function(){
    const accesso = document.getElementById("btn-accesso");
    accesso.addEventListener("click", function(){
        checkFields();
    }); 
}


function checkFields()
{
    const email= localStorage.getItem('email');
    const password= localStorage.getItem('password');

    const currentEmail= document.getElementById("email").value;
    const currentPassword= document.getElementById("password").value;

    if (email === currentEmail && password === currentPassword) {
        window.location.href = "home.html";
    } else {
        alert("Email o password errati. Riprova.");
    }
}
