"use strict"

window.addEventListener("load", function() {
    const accedi = document.getElementById("btn-accedi");
    accedi.addEventListener("click", function(){
    
         window.location.href = "accedi.html"
    });

    const registra = document.getElementById("btn-registra");
    registra.addEventListener("click", function(){
    
         window.location.href = "registrati.html"
    });

});
