    window.onload = function () {
        displayPreferiti();
    };

    function displayPreferiti() {
        const container = document.getElementById('preferiti-container');
        container.innerHTML = '';

        const preferiti = JSON.parse(localStorage.getItem('preferiti')) || [];

        if (preferiti.length === 0) {
            container.innerHTML = "";
            const p= document.createElement('p');
            p.textContent="Non hai aggiunto elementi ai preferiti";
            p.id="preferiti-message";
            container.appendChild(p);
            return;
        }

        preferiti.forEach(ricetta => {
            const ricettaElement = document.createElement('div');
            ricettaElement.classList.add('ricetta-item');

            ricettaElement.innerHTML = `
                <h3>${ricetta.title}</h3>
                <img src="${ricetta.image}" alt="${ricetta.title}">
            `;

            const actionsContainer = document.createElement('div');
            actionsContainer.classList.add('actions-container');

            const btnRimuovi = document.createElement('button');
            btnRimuovi.classList.add('btn', 'btn-danger');
            btnRimuovi.textContent = "Rimuovi dai Preferiti";
            btnRimuovi.addEventListener('click', () => {
                removeFromPreferiti(ricetta.title);       
            });

            
            const btnMostraDettagli=document.createElement('button');
            btnMostraDettagli.classList.add('btn', 'btn-primary', 'btn-preferiti');
            btnMostraDettagli.textContent = "Mostra Dettagli";
            btnMostraDettagli.addEventListener('click', () => {
                localStorage.setItem('ricettaCorrente', JSON.stringify(ricetta));
                window.location.href = 'dettagliricetta.html';
            });

            actionsContainer.appendChild(btnMostraDettagli);
            actionsContainer.appendChild(btnRimuovi);
            ricettaElement.appendChild(actionsContainer);
            container.appendChild(ricettaElement);
        });
    }

    function removeFromPreferiti(title) {
        let preferiti = JSON.parse(localStorage.getItem('preferiti')) || [];
        preferiti = preferiti.filter(pref => pref.title !== title);
        localStorage.setItem('preferiti', JSON.stringify(preferiti));
        displayPreferiti();
    }
